# Paladin文档

---
# v2.2 2018-9-11 更新
* 修复了UIAutomator中文编码问题，部署方式，将uiautomator.apk和uiautomator-androidTest.apk安装于测试手机，设置config.json中的adb路径，测试手机序列号与测试apk包名，在pc端运行: `java -jar paladin.jar`即可开始遍历。
* 保存测试图，发送http://127.0.0.1:5700/save即可保存当前遍历得到的图。
* 基于全图的回放：运行`java -jar paladin.jar -r`即可基于遍历图加速遍历
